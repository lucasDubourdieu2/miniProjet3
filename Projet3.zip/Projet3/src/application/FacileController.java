package application;

import java.util.Collections;
import java.util.Timer;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import javafx.util.Duration;

public class FacileController {
	private ObservableList<Carte> cartes =  FXCollections.observableArrayList();
	private ObservableList<Button> button =  FXCollections.observableArrayList();

	// Le premier bouton selectionné
	private Button buttonSelectionne = null;
	private Carte premierCarte;
	
	private int nombreDePaireTrouve = 0;
	
	@FXML
	private Button btnRecommencer;


	@FXML
	private Button button1;
	@FXML
	private Button button2;
	@FXML
	private Button button4;
	@FXML
	private Button button5;

	
	@FXML
	private Label timerLabel;
	private Timeline timeline;
	private Integer secondes = 30;
	
	@FXML
	private Label score;
	private int scoreNombre = 0;
	
	@FXML
	private Button fermer;
	
	@FXML
	public void initialize() {	
		
		Timer timer = new Timer();

	   	cartes.add(new Carte("1"));
    	cartes.add(new Carte("1"));	
    	cartes.add(new Carte("2"));
    	cartes.add(new Carte("2"));

    
		button.addAll(button1, button2, button4, button5 );
		Collections.shuffle(cartes);
		
		 for (int i = 0; i < cartes.size(); i++) {
	            Button monBoutton = button.get(i);
	            Carte maCarte = cartes.get(i);
	            
	            // verifCartes() quand il y a une action sur un des boutons
	            monBoutton.setOnAction(event -> verifCartes(monBoutton, maCarte));
	        }
		 
	     timeline = new Timeline();
	     timeline.setCycleCount(Timeline.INDEFINITE);
	     timeline.getKeyFrames().add(new KeyFrame(Duration.seconds(1), (ActionEvent event) -> {
	        secondes--;
	        timerLabel.setText(String.format("%d:%02d", secondes / 60, secondes % 60));
	        if (secondes <= 0) {

	            timeline.stop();
	        	Alert a = new Alert(AlertType.INFORMATION);
	        	a.setContentText("Vous avez perdu !" 
	        						+ "\nVotre score est de  : " + scoreNombre);
	        	a.setHeaderText(null);
	        	a.show();
	        	Stage stage = (Stage) fermer.getScene().getWindow();
	    	    stage.close();
	        	
	        } else if (nombreDePaireTrouve == 2 && secondes > 0) {
	        	timeline.stop();
	        	Alert a = new Alert(AlertType.INFORMATION);
	        	a.setContentText("Vous avez gagn� !" 
	        						+ "\nVotre score est de  : " + scoreNombre);
	        	a.setHeaderText(null);
	        	a.show();
	        
	        }
	      }));
	      timeline.play();
	      
	      
	
	}
	

	
	public void verifCartes(Button button, Carte carte) {
		
		// première selection
		if (buttonSelectionne == null) {
			buttonSelectionne = button;
			buttonSelectionne.setText(carte.getNom());
			premierCarte = carte;
		} else { // seconde selection
			if (buttonSelectionne == button) {
				return; // On sort de la fonction car même bouton
			}
			  if(carte.equals(premierCarte)) {
				  scoreNombre += 10;
				  buttonSelectionne.setVisible(false);
	              button.setVisible(false);
	              button.setText(carte.getNom());
	              buttonSelectionne = null; // Plus de selection
	              nombreDePaireTrouve++;
	            } else {
	            	scoreNombre -= 3;
	            	buttonSelectionne.setText("Button");
	            	button.setText("Button");
	            	buttonSelectionne = null; // Plus de selection
	            }
			  
		}
		score.setText(scoreNombre + " ");
		
	}

	@FXML
	private void fermerFenetre(ActionEvent evt) {  
		timeline.stop();
		Stage stage = (Stage) fermer.getScene().getWindow();
	    stage.close();
	    
	}
	
	@FXML
	private void recommencerAction(ActionEvent evt) {
		for (Button i : button) {
			i.setVisible(true);
			i.setText("Button");
		}
		buttonSelectionne = null;
		nombreDePaireTrouve = 0;
		scoreNombre = 0;
		timerLabel.setText("0:30");
		secondes = 30;
		score.setText("0");
		Collections.shuffle(cartes);
		for (int i = 0; i < cartes.size(); i++) {
            Button monBoutton = button.get(i);
            Carte maCarte = cartes.get(i);
            
            // verifCartes() quand il y a une action sur un des boutons
            monBoutton.setOnAction(event -> verifCartes(monBoutton, maCarte));
        }
	 
		timeline.stop();
		timeline.play();
		
		
	}
}
