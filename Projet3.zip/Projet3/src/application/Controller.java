package application;


import javafx.event.ActionEvent;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class Controller  {
	
	
	private ObservableList<String> levelstems = FXCollections.observableArrayList("Facile", "Moyen", "Difficile");
	
	@FXML
	private ChoiceBox<String> choixDiff;
	
	@FXML
	private Button fermer;

	

	@FXML
	private void actionDuBouton(ActionEvent evt) {	
		 System.out.println("le jeu se lance");
		 FXMLLoader fxmlLoader;
	        try {
	        	if (choixDiff.getValue().equals("Difficile")) {
	        		fxmlLoader = new FXMLLoader(getClass().getResource("difficileVue.fxml"));
	        	} else if (choixDiff.getValue().equals("Facile")) {
	        		fxmlLoader = new FXMLLoader(getClass().getResource("facileVue.fxml"));
	        	} else {
	        		fxmlLoader = new FXMLLoader(getClass().getResource("partieVue.fxml"));
	        	}
	            
	            Parent root1 = (Parent) fxmlLoader.load();
	            Stage stage = new Stage();
	            stage.setScene(new Scene(root1)); 
	            stage.initStyle(StageStyle.UNDECORATED);
	            stage.show();
	        } catch(Exception e) {
	        	e.printStackTrace();
	        }
	}

	@FXML
	public void initialize() {	
		choixDiff.setItems(levelstems);
		choixDiff.getSelectionModel().selectFirst();;
		
	}
	
	@FXML
	private void fermerFenetre(ActionEvent evt) {
		Platform.exit();
	}
	

}
