dubourdl@3il.fr

L'application est un jeu de "memory" d�velopp� en javaFX. J'ai dans un premier temps �tudi� le cahier des charges pour comprendre le projet et voir les fonctionnalit�es principales � d�velopper. En effet la limite de tempss m'impose de chosiir certaines fonctionnalit�s par rapport � d'autres. Par la suite j'ai cr�e une premi�re version simple de l'application sans les notions de style ni de choix de la difficult�e. J'ai pofin� la version que j'avais en ajoutant certaine des fonctionnalit�s demand�es et l'interface graphique.

J'aurais due mieux structurer ma premi�re approche du probl�me pour obtenir un premier incr�ments plus synth�tique et fonctionnel. Le fait que je ne pouvais pas utiliser GIT sur les ordinateurs de l'�cole �tait un handicap pour le projet. L'installation de javaFX et les probl�mes li�s � celle ci m'ont �galement perturb� au cour de la r�alisation de ce projet.

Ce projet m'a permis de mieux comprendre javaFX et ses fonctionnalit�s.